
import pandas as pd
from sklearn.preprocessing import LabelEncoder, OrdinalEncoder

def one_hot_encoding(df, column):
    return pd.get_dummies(df, columns=[column])

def label_encoding(df, column):
    le = LabelEncoder()
    df[column] = le.fit_transform(df[column])
    return df

def ordinal_encoding(df, column, order):
    oe = OrdinalEncoder(categories=[order])
    df[column] = oe.fit_transform(df[[column]])
    return df

def frequency_encoding(df, column):
    freq = df[column].value_counts()
    df[column] = df[column].map(freq)
    return df

def target_encoding(df, column, target):
    df = df.copy()
    df[target] = df[target].astype(float)
    means = df.groupby(column)[target].mean()
    df[column] = df[column].map(means)
    return df
