
import pandas as pd

def load_data(path):
    return pd.read_csv(path)

def handle_missing_values(df):
    df['Age'].fillna(df['Age'].mean(), inplace=True)
    df['Embarked'].fillna(df['Embarked'].mode()[0], inplace=True)
    df.drop(columns=['Cabin'], inplace=True)
    return df

def fix_datatypes(df):
    df['Survived'] = df['Survived'].astype('category')
    df['Pclass'] = df['Pclass'].astype('category')
    return df

def remove_duplicates(df):
    return df.drop_duplicates()

def drop_irrelevant_features(df):
    df.drop(columns=['PassengerId', 'Name', 'Ticket'], inplace=True)
    return df
