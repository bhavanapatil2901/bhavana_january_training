
from sklearn.preprocessing import MinMaxScaler, MaxAbsScaler, Normalizer, StandardScaler

def minmax_scaling(df, columns):
    scaler = MinMaxScaler()
    df[columns] = scaler.fit_transform(df[columns])
    return df

def maxabs_scaling(df, columns):
    scaler = MaxAbsScaler()
    df[columns] = scaler.fit_transform(df[columns])
    return df

def normalization(df, columns):
    scaler = Normalizer()
    df[columns] = scaler.fit_transform(df[columns])
    return df

def standardization(df, columns):
    scaler = StandardScaler()
    df[columns] = scaler.fit_transform(df[columns])
    return df
