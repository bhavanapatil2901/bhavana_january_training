
import numpy as np

def treat_outliers_iqr(df, column):
    Q1 = df[column].quantile(0.25)
    Q3 = df[column].quantile(0.75)
    IQR = Q3 - Q1

    lower = Q1 - 1.5 * IQR
    upper = Q3 + 1.5 * IQR

    df[column] = np.where(df[column] > upper, upper,
                   np.where(df[column] < lower, lower, df[column]))
    return df

def log_transform(df, column):
    df[column] = np.log1p(df[column])
    return df
