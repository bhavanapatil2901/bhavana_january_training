
# Data Preprocessing Project – Titanic Dataset

## Dataset
Titanic Dataset from Kaggle (Machine Learning from Disaster)

## Data Cleaning
- Handled missing values using mean and mode
- Dropped Cabin due to excessive missing values
- Fixed incorrect data types
- Removed duplicates
- Dropped irrelevant columns

## Categorical Encoding
- One-Hot Encoding
- Label Encoding
- Ordinal Encoding
- Frequency Encoding
- Target Encoding

## Feature Scaling
- Min-Max Scaling
- Max Absolute Scaling
- Normalization
- Standardization

## Outliers and Skewness
- IQR-based outlier treatment
- Log transformation for skewed features

## Conclusion
Mean and mode imputation worked best for missing values.
One-hot encoding was best for nominal features.
Standardization handled varied ranges and outliers effectively.
Outlier treatment and skewness correction improved data quality.
