import pandas as pd
from preprocessing.data_cleaning import *
from preprocessing.skewness_outliers import *
from preprocessing.categorical_encoding import *
from preprocessing.feature_scaling import *
from sklearn.model_selection import train_test_split

df = load_data("train.csv")

df = handle_missing_values(df)
df = fix_datatypes(df)
df = remove_duplicates(df)
df = drop_irrelevant_features(df)

df = treat_outliers_iqr(df, 'Fare')
df = log_transform(df, 'Fare')

df = one_hot_encoding(df, 'Sex')
df = label_encoding(df, 'Embarked')
df = frequency_encoding(df, 'Pclass')
df = target_encoding(df, 'Pclass', 'Survived')

num_cols = ['Age', 'Fare']
df = standardization(df, num_cols)

X = df.drop('Survived', axis=1)
y = df['Survived']

X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.2, random_state=42
)

print("Preprocessing completed successfully")
print(df.head())
