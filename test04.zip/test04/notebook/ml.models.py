# ============================================
# Test04 - Supervised Machine Learning (Classification)
# Breast Cancer Wisconsin Dataset
# ============================================

import pandas as pd
import numpy as np
import os
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score

from sklearn.linear_model import LogisticRegression
from sklearn.tree import DecisionTreeClassifier
from sklearn.ensemble import RandomForestClassifier
from sklearn.neighbors import KNeighborsClassifier
from sklearn.svm import SVC


# 1. Load Dataset
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
DATASET_PATH = os.path.join(BASE_DIR, "..", "dataset", "breast_cancer.csv")

df = pd.read_csv(DATASET_PATH)

print("Initial Dataset Shape:", df.shape)


# 2. Data Cleaning

# Drop irrelevant columns
df.drop(columns=['id', 'Unnamed: 32'], inplace=True)

# Check missing values
print("Missing values per column:\n", df.isnull().sum())


# Remove duplicates
df.drop_duplicates(inplace=True)

# Encode target variable
df['diagnosis'] = df['diagnosis'].map({'M': 1, 'B': 0})

print("Dataset Shape After Cleaning:", df.shape)


# 3. Feature & Target split
X = df.drop('diagnosis', axis=1)
y = df['diagnosis']


# 4. Feature Scaling
scaler = StandardScaler()
X_scaled = scaler.fit_transform(X)

print("NaN values in X_scaled:", np.isnan(X_scaled).sum())


# 5. Train-Test Split
X_train, X_test, y_train, y_test = train_test_split(
    X_scaled, y, test_size=0.2, random_state=42
)


# 6. Evaluation Function
def evaluate_model(model, X_test, y_test):
    y_pred = model.predict(X_test)
    return {
        "Accuracy": accuracy_score(y_test, y_pred),
        "Precision": precision_score(y_test, y_pred),
        "Recall": recall_score(y_test, y_pred),
        "F1-Score": f1_score(y_test, y_pred)
    }


# 7. Train & Evaluate Models

results = {}

# Logistic Regression
lr = LogisticRegression(max_iter=1000)
lr.fit(X_train, y_train)
results["Logistic Regression"] = evaluate_model(lr, X_test, y_test)

# Decision Tree
dt = DecisionTreeClassifier(random_state=42)
dt.fit(X_train, y_train)
results["Decision Tree"] = evaluate_model(dt, X_test, y_test)

# Random Forest
rf = RandomForestClassifier(n_estimators=100, random_state=42)
rf.fit(X_train, y_train)
results["Random Forest"] = evaluate_model(rf, X_test, y_test)

# KNN
knn = KNeighborsClassifier(n_neighbors=5)
knn.fit(X_train, y_train)
results["KNN"] = evaluate_model(knn, X_test, y_test)

# SVM
svm = SVC()
svm.fit(X_train, y_train)
results["SVM"] = evaluate_model(svm, X_test, y_test)


# 8. Results
results_df = pd.DataFrame(results)
print("\nModel Performance Comparison:\n")
print(results_df)
