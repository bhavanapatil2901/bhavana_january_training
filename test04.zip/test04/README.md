# Test04 – Supervised Machine Learning Classification Project

## Project Title
Breast Cancer Classification Using Supervised Machine Learning


## Problem Statement
The objective of this project is to build and evaluate multiple supervised machine learning
models to classify breast tumors as **Malignant** or **Benign** based on diagnostic features.
The project also emphasizes proper data preprocessing, model training, and performance evaluation.


## Dataset Description
The dataset used is the **Breast Cancer Wisconsin (Diagnostic) Dataset**.

- Total records: 569
- Target variable: `diagnosis`
  - M → Malignant (1)
  - B → Benign (0)
- Features: Numerical features computed from digitized images of breast mass cell nuclei

The dataset is included in the repository under the `dataset/` folder as required.


## Data Cleaning & Preprocessing
The following preprocessing steps were performed before applying machine learning algorithms:

1. **Removed irrelevant columns**
   - `id` column (no predictive value)
   - `Unnamed: 32` column (contained only missing values)

2. **Handled missing values**
   - Dataset contained no valid missing values after removing empty column

3. **Removed duplicate records**
   - Ensured data consistency and avoided biased learning

4. **Categorical encoding**
   - Target variable `diagnosis` encoded as:
     - Malignant → 1
     - Benign → 0

5. **Feature scaling**
   - Applied `StandardScaler` to normalize feature values
   - Required for distance-based and margin-based models like KNN and SVM

6. **Train–Test split**
   - 80% Training data
   - 20% Testing data


## Algorithms Used
The following five supervised machine learning algorithms were implemented:

1. Logistic Regression  
2. Decision Tree Classifier  
3. Random Forest Classifier  
4. K-Nearest Neighbors (KNN)  
5. Support Vector Machine (SVM)



## Evaluation Metrics
All models were evaluated using the following classification metrics:

- Accuracy
- Precision
- Recall
- F1-Score


## Model Performance Results

| Model                | Accuracy | Precision | Recall | F1-Score |
|----------------------|----------|-----------|--------|----------|
| Logistic Regression  | 96.49%   | 95.45%    | 95.45% | 95.45%   |
| Decision Tree        | 93.86%   | 93.02%    | 93.02% | 93.02%   |
| Random Forest        | 98.25%   | 97.78%    | 97.78% | 97.78%   |
| KNN                  | 95.61%   | 94.74%    | 94.74% | 94.74%   |
| SVM                  | 97.37%   | 96.67%    | 96.67% | 96.67%   |


## Conclusion / Observations
- All five supervised learning models performed well on the dataset.
- **Random Forest** achieved the highest overall performance with approximately **98% accuracy**.
- **SVM** and **Logistic Regression** also showed strong and stable results.
- Proper data preprocessing and feature scaling significantly improved model performance.
- Ensemble methods proved more robust compared to single classifiers.

This project demonstrates the importance of data cleaning, model comparison, and evaluation
in supervised machine learning classification tasks.

