import pandas as pd
from sklearn.preprocessing import StandardScaler
from sklearn.cluster import KMeans
from sklearn.metrics import silhouette_score

data = pd.read_csv('data.csv')
scaler = StandardScaler()
X = scaler.fit_transform(data)

kmeans = KMeans(n_clusters=4, random_state=42)
labels = kmeans.fit_predict(X)

print("Clusters:", len(set(labels)))
print("Silhouette Score:", silhouette_score(X, labels))
