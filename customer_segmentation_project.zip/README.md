# Customer Segmentation Project

## Objective
Segment customers using unsupervised learning.

## Algorithms Used
- KMeans
- DBSCAN
- Hierarchical Clustering

## How to Run
pip install -r requirements.txt
python main.py
